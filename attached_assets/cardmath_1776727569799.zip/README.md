
# CardMath

## How to run in Replit
1. Create Node.js Repl
2. Upload files
3. Run: npm install
4. Run: npm start
5. Open web preview (port 3000)

## Concept
Track credit card fees vs real benefit usage.

## UI Theme
Blue + green sleek fintech style
