
const express = require("express");
const app = express();

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

let cards = [];

function calcNet(card) {
  const used = card.benefitsUsed.reduce((a,b)=>a+b.value,0);
  return used - card.annualFee;
}

app.get("/", (req,res)=>{
  res.render("index",{cards});
});

app.get("/add",(req,res)=>{
  res.render("add-card");
});

app.post("/add",(req,res)=>{
  const {name,annualFee} = req.body;
  cards.push({
    id: Date.now(),
    name,
    annualFee: parseFloat(annualFee),
    benefitsUsed:[]
  });
  res.redirect("/");
});

app.get("/card/:id",(req,res)=>{
  const card = cards.find(c=>c.id==req.params.id);
  res.render("dashboard",{card,net:calcNet(card)});
});

app.listen(3000,()=>console.log("CardMath running"));
